import json

from predict_utilities import predict
from model_utilities import model_loader
from arguments_processor import get_predict_args

# get input args from command-line
in_args = get_predict_args()

image_path = in_args.image_path
checkpoint = in_args.checkpoint
topk = in_args.topk
category_names = in_args.category_names
gpu = in_args.gpu

flowers_names = None

print(f'Image path: {image_path}')
print(f'checkpoint used: {checkpoint}')
print(f'Top-K classes inferenced num: {topk}')

print(f'Computation mode: {"GPU ENABLED" if gpu else "CPU ENABLED"}\n')

# load the checkpoint model
checkpoint_model, _ = model_loader(checkpoint)

# make inference and get results: probs and classes
probs, classes = predict(image_path, checkpoint_model, topk=topk, gpu=gpu)

if category_names: 
    print(f'file used for mapping categories to real names: {category_names}')
    with open(category_names, 'r') as file:
        cat_to_name = json.load(file)
    
    flowers_names = [cat_to_name[id] for id in classes]

print('Results:\n')
print('inferenced Probabilities, inferenced Classes:')
print(probs)
print(classes)

if flowers_names:
    print('flowers names:')
    print(flowers_names)


# ##########################################################################

# Testings:
# Testing 1:  on the new network trained resnet101 in the Image Classifier Part2:
# predict.py script tested on the following command-line:
# python predict.py flowers/test/95/image_07584.jpg checkpoints_dir/resnet101_checkpoint.pth --gpu --category_names cat_to_name.json
# Inference inputs
# Image path: flowers/test/95/image_07584.jpg
# checkpoint used: checkpoints_dir/resnet101_checkpoint.pth
# Top-K classes inferenced num: 1
# Computation mode: GPU ENABLED
# file used for mapping categories to real names: cat_to_name.json

# Inference Results:
# inferenced Probabilities, inferenced Classes:
# [0.9856470227241516]
# ['95']
# flowers names:
# ['bougainvillea']

# ##########################################################################

# Testing 2: on the vgg19 network that trained in the notebook from Image Classifier Part1:
# predict.py script tested on the following command-line:
# python predict.py flowers/test/1/image_06754.jpg checkpoints_dir/vgg19_checkpoint.pth  --category_names cat_to_name.json

# Inference inputs
# Image path: flowers/test/1/image_06754.jpg
# checkpoint used: checkpoints_dir/vgg19_checkpoint.pth
# Top-K classes inferenced num: 5
# Computation mode: CPU ENABLED
# file used for mapping categories to real names: cat_to_name.json

# Inference Results:
# inferenced Probabilities, inferenced Classes:
# [0.9800348281860352, 0.011538635939359665, 0.004840980749577284, 0.001717209117487073, 0.0007444494403898716]
# ['1', '97', '96', '98', '19']
# flowers names:
# ['pink primrose', 'mallow', 'camellia', 'mexican petunia', 'balloon flower']
